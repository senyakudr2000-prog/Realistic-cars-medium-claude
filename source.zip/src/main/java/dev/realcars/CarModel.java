package dev.realcars;

import java.util.Random;

/**
 * Car body geometry shared by server (damage) and client (rendering).
 * The body is a lattice of NU x NV x NW vertices. Every vertex has a rest position and a
 * dent offset; the renderer draws the lattice surface, so dents deform the real mesh.
 *
 * Local axes: +x = left side of the car, +y = up (0 = ground), +z = forward.
 */
public final class CarModel {
    public static final int NU = 13; // along length, 0 = rear, NU-1 = front
    public static final int NV = 7;  // across width, 0 = right side, NV-1 = left side
    public static final int NW = 4;  // height layers, 0 = bottom, NW-1 = top
    public static final int VERTS = NU * NV * NW;

    public static final float HX = 0.9f;   // half width
    public static final float HZ = 1.5f;   // half length
    public static final float BOTTOM = 0.28f;
    public static final float MAX_DENT = 1.2f;

    public static final int GLASS_WINDSHIELD = 0;
    public static final int GLASS_REAR = 1;
    public static final int GLASS_LEFT = 2;
    public static final int GLASS_RIGHT = 3;

    // Top surface height for each length index (rear -> front)
    private static final float[] TOP = {
            1.05f, 1.07f, 1.08f, 1.40f, 1.70f, 1.70f, 1.70f, 1.45f, 1.15f, 1.08f, 1.05f, 1.02f, 1.00f
    };

    /** Rest positions, x,y,z per vertex. */
    public static final float[] REST = new float[VERTS * 3];
    /** Centre of each glass panel in rest pose. */
    public static final float[][] GLASS_CENTER = new float[4][3];

    static {
        for (int iu = 0; iu < NU; iu++) {
            for (int iv = 0; iv < NV; iv++) {
                for (int iw = 0; iw < NW; iw++) {
                    int i = index(iu, iv, iw) * 3;
                    float u = 2f * iu / (NU - 1) - 1f;
                    float v = 2f * iv / (NV - 1) - 1f;
                    float wf = iw / (float) (NW - 1);
                    float taper = 1f - 0.10f * wf;
                    float round = 1f - 0.14f * u * u * u * u;
                    REST[i] = v * HX * taper * round; // iv=0 is right side => negative x
                    REST[i + 1] = BOTTOM + (TOP[iu] - BOTTOM) * wf;
                    REST[i + 2] = u * HZ;
                }
            }
        }
        int[] count = new int[4];
        for (int iu = 0; iu < NU - 1; iu++) {
            for (int iv = 0; iv < NV - 1; iv++) {
                int p = topGlass(iu, iv);
                if (p >= 0) accumulate(p, count, iu, iv, NW - 1, iu + 1, iv + 1, NW - 1);
            }
        }
        for (int iu = 0; iu < NU - 1; iu++) {
            for (int iw = 0; iw < NW - 1; iw++) {
                int p = sideGlass(iu, iw, true);
                if (p >= 0) accumulate(p, count, iu, 0, iw, iu + 1, 0, iw + 1);
                p = sideGlass(iu, iw, false);
                if (p >= 0) accumulate(p, count, iu, NV - 1, iw, iu + 1, NV - 1, iw + 1);
            }
        }
        for (int p = 0; p < 4; p++) {
            if (count[p] > 0) {
                for (int k = 0; k < 3; k++) GLASS_CENTER[p][k] /= count[p];
            }
        }
    }

    private static void accumulate(int p, int[] count, int u0, int v0, int w0, int u1, int v1, int w1) {
        for (int k = 0; k < 3; k++) {
            float a = REST[index(u0, v0, w0) * 3 + k];
            float b = REST[index(u1, v1, w1) * 3 + k];
            float c = REST[index(u0, v1, w0) * 3 + k];
            float d = REST[index(u1, v0, w1) * 3 + k];
            GLASS_CENTER[p][k] += (a + b + c + d) / 4f;
        }
        count[p]++;
    }

    private CarModel() {}

    public static int index(int iu, int iv, int iw) {
        return (iu * NV + iv) * NW + iw;
    }

    /** Glass panel id for a top-surface cell (iu, iv), or -1. */
    public static int topGlass(int iu, int iv) {
        if (iv < 1 || iv > NV - 3) return -1;
        if (iu == 6 || iu == 7) return GLASS_WINDSHIELD;
        if (iu == 2 || iu == 3) return GLASS_REAR;
        return -1;
    }

    /** Glass panel id for a side-surface cell, or -1. */
    public static int sideGlass(int iu, int iw, boolean rightSide) {
        if (iw != NW - 2) return -1;
        if (iu < 3 || iu > 7) return -1;
        return rightSide ? GLASS_RIGHT : GLASS_LEFT;
    }

    public static float px(float[] dents, int i) { return REST[i * 3] + dents[i * 3]; }
    public static float py(float[] dents, int i) { return REST[i * 3 + 1] + dents[i * 3 + 1]; }
    public static float pz(float[] dents, int i) { return REST[i * 3 + 2] + dents[i * 3 + 2]; }

    /**
     * Surface contact point for an impact coming from local direction (dx,dy,dz)
     * (direction from the car centre towards the obstacle).
     */
    public static float[] contactPoint(double dx, double dy, double dz) {
        double hy = 0.75;
        double cy = (Math.abs(dy) < 0.2) ? 0.75 : 0.9;
        double m = Math.max(Math.abs(dx) / HX, Math.max(Math.abs(dy) / hy, Math.abs(dz) / HZ));
        if (m < 1e-6) return new float[]{0f, (float) cy, 0f};
        double t = 1.0 / m;
        return new float[]{(float) (dx * t), (float) (cy + dy * t), (float) (dz * t)};
    }

    /**
     * Pushes lattice vertices around point P along the inward direction I (unit vector),
     * with squared falloff inside the radius and a little random crumple noise.
     */
    public static void applyDent(float[] dents, float px, float py, float pz,
                                 float ix, float iy, float iz,
                                 float radius, float depth, Random rnd) {
        for (int i = 0; i < VERTS; i++) {
            float vx = REST[i * 3] + dents[i * 3];
            float vy = REST[i * 3 + 1] + dents[i * 3 + 1];
            float vz = REST[i * 3 + 2] + dents[i * 3 + 2];
            float dx = vx - px, dy = vy - py, dz = vz - pz;
            float dist = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dist >= radius) continue;
            float w = 1f - dist / radius;
            w *= w;
            float amt = depth * w;
            float noise = 0.30f * amt;
            dents[i * 3] = clamp(dents[i * 3] + ix * amt + (rnd.nextFloat() - 0.5f) * noise);
            dents[i * 3 + 1] = clamp(dents[i * 3 + 1] + iy * amt + (rnd.nextFloat() - 0.5f) * noise);
            dents[i * 3 + 2] = clamp(dents[i * 3 + 2] + iz * amt + (rnd.nextFloat() - 0.5f) * noise);
        }
    }

    private static float clamp(float v) {
        return Math.max(-MAX_DENT, Math.min(MAX_DENT, v));
    }

    public static byte[] encode(float[] dents) {
        byte[] out = new byte[VERTS * 3];
        for (int i = 0; i < out.length; i++) {
            long q = Math.round(dents[i] * 100f);
            out[i] = (byte) Math.max(-127, Math.min(127, q));
        }
        return out;
    }

    public static void decode(byte[] in, float[] dents) {
        if (in.length != VERTS * 3) {
            java.util.Arrays.fill(dents, 0f);
            return;
        }
        for (int i = 0; i < in.length; i++) dents[i] = in[i] / 100f;
    }
}

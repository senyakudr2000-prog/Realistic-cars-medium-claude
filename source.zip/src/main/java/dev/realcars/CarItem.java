package dev.realcars;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Places a car on the block that was clicked. */
public class CarItem extends Item {
    public CarItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        if (world.isClient) return ActionResult.SUCCESS;

        Vec3d pos = Vec3d.ofBottomCenter(context.getBlockPos().offset(context.getSide()));
        CarEntity car = RealCarsMod.CAR.create(world);
        if (car == null) return ActionResult.FAIL;

        // face the same way as the player
        car.refreshPositionAndAngles(pos.x, pos.y, pos.z, context.getPlayerYaw(), 0f);
        if (!world.isSpaceEmpty(car, car.getBoundingBox())) return ActionResult.FAIL;

        world.spawnEntity(car);
        PlayerEntity player = context.getPlayer();
        if (player == null || !player.isCreative()) context.getStack().decrement(1);
        return ActionResult.CONSUME;
    }
}

package dev.realcars;

import net.minecraft.block.Blocks;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

/** Server-side crash handling: dents, glass, damage, sounds and particles. */
public final class CarDamage {
    private CarDamage() {}

    /**
     * @param dirWorld direction from the car centre towards the thing it hit (world space)
     * @param severity momentum lost in blocks/tick (0.25 = fender bender, 0.8+ = heavy crash)
     */
    public static void apply(CarEntity car, Vec3d dirWorld, double severity) {
        if (car.getWorld().isClient || severity <= 0.0 || dirWorld.lengthSquared() < 1.0E-8) return;
        ServerWorld world = (ServerWorld) car.getWorld();

        Vec3d dl = car.worldToLocal(dirWorld.normalize());
        float[] p = CarModel.contactPoint(dl.x, dl.y, dl.z);
        float radius = (float) (0.45 + severity * 0.9);
        float depth = (float) Math.min(0.65, severity);
        Random rnd = new Random(car.getRandom().nextLong());

        CarModel.applyDent(car.dents, p[0], p[1], p[2],
                (float) -dl.x, (float) -dl.y, (float) -dl.z, radius, depth, rnd);

        car.setDamage(MathHelper.clamp(car.getDamage() + (float) (severity * severity * 0.9), 0f, 1f));

        // Glass
        int glass = car.getGlass();
        for (int g = 0; g < 4; g++) {
            if ((glass & (1 << g)) != 0) continue; // already shattered
            float[] c = CarModel.GLASS_CENTER[g];
            double dx = p[0] - c[0], dy = p[1] - c[1], dz = p[2] - c[2];
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            double w = 1.0 - dist / (radius + 0.6);
            if (w <= 0) continue;
            double strength = severity * w;
            if (strength > 0.22) {
                glass |= (1 << g);
                glass &= ~(1 << (g + 4));
                Vec3d gp = car.localToWorld(c[0], c[1], c[2]);
                world.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.GLASS.getDefaultState()),
                        gp.x, gp.y, gp.z, 30, 0.35, 0.25, 0.35, 0.15);
                world.playSound(null, gp.x, gp.y, gp.z, SoundEvents.BLOCK_GLASS_BREAK,
                        SoundCategory.NEUTRAL, 1.0f, 0.8f + rnd.nextFloat() * 0.4f);
            } else if (strength > 0.08) {
                glass |= (1 << (g + 4));
            }
        }
        car.setGlass(glass);

        // Sound and sparks at the contact point
        Vec3d wp = car.localToWorld(p[0], p[1], p[2]);
        float vol = (float) Math.min(1.6, 0.5 + severity * 1.5);
        if (severity > 0.45) {
            world.playSound(null, wp.x, wp.y, wp.z, SoundEvents.ENTITY_IRON_GOLEM_DAMAGE,
                    SoundCategory.NEUTRAL, vol, 0.5f + rnd.nextFloat() * 0.2f);
        }
        world.playSound(null, wp.x, wp.y, wp.z, SoundEvents.BLOCK_METAL_HIT,
                SoundCategory.NEUTRAL, vol, 0.5f + rnd.nextFloat() * 0.3f);
        int sparks = (int) Math.min(30, 4 + severity * 30);
        world.spawnParticles(ParticleTypes.CRIT, wp.x, wp.y, wp.z, sparks, 0.25, 0.2, 0.25, 0.35);
        world.spawnParticles(ParticleTypes.LARGE_SMOKE, wp.x, wp.y, wp.z, 2 + (int) (severity * 6), 0.2, 0.15, 0.2, 0.02);

        car.syncDents();
    }
}

package dev.realcars.client;

import dev.realcars.CarEntity;
import dev.realcars.CarModel;
import dev.realcars.RealCarsMod;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

import java.util.ArrayList;
import java.util.List;

import static dev.realcars.CarModel.*;

/** Draws the deformable lattice body, spinning wheels and (cracked) glass. */
public class CarRenderer extends EntityRenderer<CarEntity> {
    private static final Identifier WHITE = Identifier.of(RealCarsMod.MOD_ID, "textures/entity/white.png");
    private static final Identifier CRACK = Identifier.of(RealCarsMod.MOD_ID, "textures/entity/crack.png");

    private static final int DARK = 0x232326;
    private static final int HEADLIGHT = 0xFFF0AA;
    private static final int TAILLIGHT = 0xBE1919;
    private static final int GLASS_RGB = 0x9CC4D8;

    private record GlassCell(int panel, int[] idx, float[] uv) {}

    private static final List<GlassCell> GLASS_CELLS = buildGlassCells();

    public CarRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
        this.shadowRadius = 1.1f;
    }

    @Override
    public Identifier getTexture(CarEntity car) {
        return WHITE;
    }

    @Override
    public void render(CarEntity car, float entityYaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vcp, int light) {
        float yaw = MathHelper.lerpAngleDegrees(tickDelta, car.prevYaw, car.getYaw());
        matrices.push();
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-yaw));

        float[] dents = car.getDentOffsets();
        float[] pos = new float[VERTS * 3];
        for (int i = 0; i < pos.length; i++) pos[i] = REST[i] + dents[i];
        int rgb = car.getColor();
        int glass = car.getGlass();

        // 1) body + wheels (same render layer, finished before the next layer is requested)
        VertexConsumer body = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(WHITE));
        drawBody(body, matrices.peek(), pos, rgb, light);
        float spin = MathHelper.lerp(tickDelta, car.prevWheelSpin, car.wheelSpin);
        float steer = MathHelper.lerp(tickDelta, car.prevWheelSteer, car.wheelSteer);
        drawWheel(body, matrices, -0.82f, 0.32f, 0.95f, true, steer, spin, light);
        drawWheel(body, matrices, 0.82f, 0.32f, 0.95f, true, steer, spin, light);
        drawWheel(body, matrices, -0.82f, 0.32f, -0.95f, false, 0f, spin, light);
        drawWheel(body, matrices, 0.82f, 0.32f, -0.95f, false, 0f, spin, light);

        // 2) glass (tinted, translucent). Shattered panels are skipped entirely.
        MatrixStack.Entry entry = matrices.peek();
        VertexConsumer glassVc = vcp.getBuffer(RenderLayer.getEntityTranslucent(WHITE));
        for (GlassCell cell : GLASS_CELLS) {
            if ((glass & (1 << cell.panel)) != 0) continue;
            quad(glassVc, entry, pos, cell.idx, GLASS_RGB, 90, light, null);
        }

        // 3) crack overlay on cracked (not shattered) panels
        if ((glass & 0xF0) != 0) {
            VertexConsumer crackVc = vcp.getBuffer(RenderLayer.getEntityTranslucent(CRACK));
            for (GlassCell cell : GLASS_CELLS) {
                boolean shattered = (glass & (1 << cell.panel)) != 0;
                boolean cracked = (glass & (1 << (cell.panel + 4))) != 0;
                if (shattered || !cracked) continue;
                quad(crackVc, entry, pos, cell.idx, 0xFFFFFF, 230, light, cell.uv);
            }
        }

        matrices.pop();
        super.render(car, entityYaw, tickDelta, matrices, vcp, light);
    }

    // ------------------------------------------------------------------ body

    private void drawBody(VertexConsumer vc, MatrixStack.Entry e, float[] pos, int rgb, int light) {
        // top
        for (int iu = 0; iu < NU - 1; iu++) {
            for (int iv = 0; iv < NV - 1; iv++) {
                if (topGlass(iu, iv) >= 0) continue;
                int[] q = {index(iu, iv, NW - 1), index(iu + 1, iv, NW - 1), index(iu + 1, iv + 1, NW - 1), index(iu, iv + 1, NW - 1)};
                quad(vc, e, pos, q, rgb, 255, light, null);
            }
        }
        // underside
        for (int iu = 0; iu < NU - 1; iu++) {
            for (int iv = 0; iv < NV - 1; iv++) {
                int[] q = {index(iu, iv, 0), index(iu + 1, iv, 0), index(iu + 1, iv + 1, 0), index(iu, iv + 1, 0)};
                quad(vc, e, pos, q, DARK, 255, light, null);
            }
        }
        // sides
        for (int side = 0; side < 2; side++) {
            int iv = side == 0 ? 0 : NV - 1;
            for (int iu = 0; iu < NU - 1; iu++) {
                for (int iw = 0; iw < NW - 1; iw++) {
                    if (sideGlass(iu, iw, side == 0) >= 0) continue;
                    int[] q = {index(iu, iv, iw), index(iu + 1, iv, iw), index(iu + 1, iv, iw + 1), index(iu, iv, iw + 1)};
                    quad(vc, e, pos, q, iw == 0 ? DARK : rgb, 255, light, null);
                }
            }
        }
        // front and back
        for (int end = 0; end < 2; end++) {
            int iu = end == 0 ? NU - 1 : 0;
            for (int iv = 0; iv < NV - 1; iv++) {
                for (int iw = 0; iw < NW - 1; iw++) {
                    int c = rgb;
                    boolean corner = iv == 0 || iv == NV - 2;
                    if (iw == 0) c = DARK;
                    else if (iw == 1 && corner) c = end == 0 ? HEADLIGHT : TAILLIGHT;
                    else if (iw == 1 && end == 0 && (iv == 2 || iv == 3)) c = DARK;
                    int[] q = {index(iu, iv, iw), index(iu, iv + 1, iw), index(iu, iv + 1, iw + 1), index(iu, iv, iw + 1)};
                    quad(vc, e, pos, q, c, 255, light, null);
                }
            }
        }
    }

    // ------------------------------------------------------------------ wheels

    private void drawWheel(VertexConsumer vc, MatrixStack matrices, float x, float y, float z,
                           boolean front, float steer, float spin, int light) {
        matrices.push();
        matrices.translate(x, y, z);
        if (front) matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(steer));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(spin));
        MatrixStack.Entry e = matrices.peek();

        final int seg = 10;
        final float r = 0.32f, hw = 0.12f;
        for (int s = 0; s < seg; s++) {
            double a0 = Math.PI * 2.0 * s / seg;
            double a1 = Math.PI * 2.0 * (s + 1) / seg;
            float y0 = (float) (r * Math.cos(a0)), z0 = (float) (r * Math.sin(a0));
            float y1 = (float) (r * Math.cos(a1)), z1 = (float) (r * Math.sin(a1));
            double am = (a0 + a1) / 2.0;
            int tread = (s % 2 == 0) ? 0x1E1E1E : 0x363636;
            raw(vc, e, new float[]{-hw, y0, z0, hw, y0, z0, hw, y1, z1, -hw, y1, z1},
                    0f, (float) Math.cos(am), (float) Math.sin(am), tread, light);
            int hub = (s % 2 == 0) ? 0x9A9AA0 : 0x6E6E74;
            raw(vc, e, new float[]{hw, 0, 0, hw, y0, z0, hw, y1, z1, hw, y1, z1}, 1f, 0f, 0f, hub, light);
            raw(vc, e, new float[]{-hw, 0, 0, -hw, y1, z1, -hw, y0, z0, -hw, y0, z0}, -1f, 0f, 0f, hub, light);
        }
        matrices.pop();
    }

    // ------------------------------------------------------------------ quad helpers

    private static void raw(VertexConsumer vc, MatrixStack.Entry e, float[] v, float nx, float ny, float nz,
                            int rgb, int light) {
        int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
        for (int k = 0; k < 4; k++) {
            vc.vertex(e.getPositionMatrix(), v[k * 3], v[k * 3 + 1], v[k * 3 + 2])
                    .color(r, g, b, 255)
                    .texture(0.5f, 0.5f)
                    .overlay(OverlayTexture.DEFAULT_UV)
                    .light(light)
                    .normal(e, nx, ny, nz);
        }
    }

    /** Emits one lattice quad with a flat normal that always points away from the body centre. */
    private static void quad(VertexConsumer vc, MatrixStack.Entry e, float[] pos, int[] idx,
                             int rgb, int alpha, int light, float[] uv) {
        float[] p = new float[12];
        for (int k = 0; k < 4; k++) {
            p[k * 3] = pos[idx[k] * 3];
            p[k * 3 + 1] = pos[idx[k] * 3 + 1];
            p[k * 3 + 2] = pos[idx[k] * 3 + 2];
        }
        float ax = p[6] - p[0], ay = p[7] - p[1], az = p[8] - p[2];
        float bx = p[9] - p[3], by = p[10] - p[4], bz = p[11] - p[5];
        float nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
        float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (len < 1.0E-6f) return;
        nx /= len;
        ny /= len;
        nz /= len;
        float cx = (p[0] + p[3] + p[6] + p[9]) / 4f;
        float cy = (p[1] + p[4] + p[7] + p[10]) / 4f - 0.85f;
        float cz = (p[2] + p[5] + p[8] + p[11]) / 4f;
        if (nx * cx + ny * cy + nz * cz < 0f) {
            nx = -nx;
            ny = -ny;
            nz = -nz;
        }
        int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
        for (int k = 0; k < 4; k++) {
            float u = uv == null ? 0.5f : uv[k * 2];
            float v = uv == null ? 0.5f : uv[k * 2 + 1];
            vc.vertex(e.getPositionMatrix(), p[k * 3], p[k * 3 + 1], p[k * 3 + 2])
                    .color(r, g, b, alpha)
                    .texture(u, v)
                    .overlay(OverlayTexture.DEFAULT_UV)
                    .light(light)
                    .normal(e, nx, ny, nz);
        }
    }

    private static List<GlassCell> buildGlassCells() {
        List<GlassCell> cells = new ArrayList<>();
        // windshield + rear window on the top surface (2 cells long, 4 cells wide)
        for (int iu = 0; iu < NU - 1; iu++) {
            for (int iv = 0; iv < NV - 1; iv++) {
                int p = topGlass(iu, iv);
                if (p < 0) continue;
                int base = p == GLASS_WINDSHIELD ? 6 : 2;
                int[] idx = {index(iu, iv, NW - 1), index(iu + 1, iv, NW - 1), index(iu + 1, iv + 1, NW - 1), index(iu, iv + 1, NW - 1)};
                int[][] corner = {{0, 0}, {1, 0}, {1, 1}, {0, 1}}; // {du, dv}
                float[] uv = new float[8];
                for (int k = 0; k < 4; k++) {
                    uv[k * 2] = (iv + corner[k][1] - 1) / 4f;
                    uv[k * 2 + 1] = (iu + corner[k][0] - base) / 2f;
                }
                cells.add(new GlassCell(p, idx, uv));
            }
        }
        // side windows (5 cells long, 1 tall)
        for (int side = 0; side < 2; side++) {
            int iv = side == 0 ? 0 : NV - 1;
            for (int iu = 0; iu < NU - 1; iu++) {
                int iw = NW - 2;
                int p = sideGlass(iu, iw, side == 0);
                if (p < 0) continue;
                int[] idx = {index(iu, iv, iw), index(iu + 1, iv, iw), index(iu + 1, iv, iw + 1), index(iu, iv, iw + 1)};
                int[][] corner = {{0, 0}, {1, 0}, {1, 1}, {0, 1}}; // {du, dw}
                float[] uv = new float[8];
                for (int k = 0; k < 4; k++) {
                    uv[k * 2] = (iu + corner[k][0] - 3) / 5f;
                    uv[k * 2 + 1] = 1f - corner[k][1];
                }
                cells.add(new GlassCell(p, idx, uv));
            }
        }
        return cells;
    }
}

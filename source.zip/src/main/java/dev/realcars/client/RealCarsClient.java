package dev.realcars.client;

import dev.realcars.RealCarsMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class RealCarsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(RealCarsMod.CAR, CarRenderer::new);
    }
}

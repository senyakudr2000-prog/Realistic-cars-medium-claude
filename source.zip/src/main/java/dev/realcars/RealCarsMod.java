package dev.realcars;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class RealCarsMod implements ModInitializer {
    public static final String MOD_ID = "realcars";

    public static final EntityType<CarEntity> CAR = Registry.register(
            Registries.ENTITY_TYPE,
            Identifier.of(MOD_ID, "car"),
            FabricEntityTypeBuilder.<CarEntity>create(SpawnGroup.MISC, CarEntity::new)
                    .dimensions(EntityDimensions.fixed(2.2f, 1.7f))
                    .trackRangeBlocks(128)
                    .trackedUpdateRate(1)
                    .forceTrackedVelocityUpdates(true)
                    .build());

    public static final Item CAR_ITEM = Registry.register(
            Registries.ITEM,
            Identifier.of(MOD_ID, "car"),
            new CarItem(new Item.Settings().maxCount(1)));

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> entries.add(CAR_ITEM));
    }
}

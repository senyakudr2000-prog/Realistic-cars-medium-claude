package dev.realcars;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.Arrays;
import java.util.List;

/**
 * A drivable car. Physics run on the server only (server authoritative); the driver's
 * W/A/S/D input arrives through the vanilla player-input packet. Clients interpolate.
 */
public class CarEntity extends Entity {
    private static final TrackedData<Float> DAMAGE = DataTracker.registerData(CarEntity.class, TrackedDataHandlerRegistry.FLOAT);
    private static final TrackedData<Integer> COLOR = DataTracker.registerData(CarEntity.class, TrackedDataHandlerRegistry.INTEGER);
    /** bits 0-3: shattered panels, bits 4-7: cracked panels */
    private static final TrackedData<Integer> GLASS = DataTracker.registerData(CarEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<NbtCompound> DENTS = DataTracker.registerData(CarEntity.class, TrackedDataHandlerRegistry.NBT_COMPOUND);

    private static final int[] PALETTE = {
            0xC0392B, 0x2471A3, 0xECF0F1, 0x1C1C1C, 0xF1C40F, 0x27AE60, 0xAAB7B8, 0xE67E22
    };

    // Driving model (blocks per tick)
    private static final double MAX_SPEED = 1.0;
    private static final double ACCEL = 0.03;
    private static final double BRAKE = 0.06;
    private static final double REV_ACCEL = 0.015;
    private static final double MAX_REVERSE = 0.25;
    private static final double WHEELBASE = 2.0;

    /** Dent offsets per lattice vertex (x,y,z). Authoritative on the server, decoded on the client. */
    public final float[] dents = new float[CarModel.VERTS * 3];
    private NbtCompound lastDentTag;

    // client side interpolation / visuals
    private int lerpSteps;
    private double lerpX, lerpY, lerpZ;
    private float lerpYaw;
    public float wheelSpin, prevWheelSpin, wheelSteer, prevWheelSteer;

    public CarEntity(EntityType<? extends CarEntity> type, World world) {
        super(type, world);
        if (!world.isClient) {
            dataTracker.set(COLOR, PALETTE[this.random.nextInt(PALETTE.length)]);
        }
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        builder.add(DAMAGE, 0f);
        builder.add(COLOR, 0xC0392B);
        builder.add(GLASS, 0);
        builder.add(DENTS, new NbtCompound());
    }

    // ---------------------------------------------------------------- state accessors

    public float getDamage() { return dataTracker.get(DAMAGE); }
    public void setDamage(float v) { dataTracker.set(DAMAGE, MathHelper.clamp(v, 0f, 1f)); }
    public int getColor() { return dataTracker.get(COLOR); }
    public void setColor(int rgb) { dataTracker.set(COLOR, rgb & 0xFFFFFF); }
    public int getGlass() { return dataTracker.get(GLASS); }
    public void setGlass(int bits) { dataTracker.set(GLASS, bits); }

    /** Client: decodes the synced dent array when it changes. Server: just returns the array. */
    public float[] getDentOffsets() {
        if (getWorld().isClient) {
            NbtCompound tag = dataTracker.get(DENTS);
            if (tag != lastDentTag) {
                lastDentTag = tag;
                CarModel.decode(tag.getByteArray("d"), dents);
            }
        }
        return dents;
    }

    /** Server: pushes the dent array to tracking clients. */
    public void syncDents() {
        NbtCompound tag = new NbtCompound();
        tag.putByteArray("d", CarModel.encode(dents));
        dataTracker.set(DENTS, tag);
    }

    // ---------------------------------------------------------------- local space helpers

    /** Local (x=left, y=up, z=forward) point to world position. */
    public Vec3d localToWorld(double lx, double ly, double lz) {
        double yr = Math.toRadians(getYaw());
        double c = Math.cos(yr), s = Math.sin(yr);
        return new Vec3d(getX() + lx * c - lz * s, getY() + ly, getZ() + lx * s + lz * c);
    }

    /** World direction vector to local direction vector. */
    public Vec3d worldToLocal(Vec3d d) {
        double yr = Math.toRadians(getYaw());
        double c = Math.cos(yr), s = Math.sin(yr);
        return new Vec3d(d.x * c + d.z * s, d.y, -d.x * s + d.z * c);
    }

    // ---------------------------------------------------------------- tick

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient) {
            clientTick();
        } else {
            serverTick();
        }
    }

    @Override
    public void updateTrackedPositionAndAngles(double x, double y, double z, float yaw, float pitch, int interpolationSteps) {
        lerpX = x;
        lerpY = y;
        lerpZ = z;
        lerpYaw = yaw;
        lerpSteps = 3;
    }

    private void clientTick() {
        if (lerpSteps > 0) {
            double k = 1.0 / lerpSteps;
            setPosition(getX() + (lerpX - getX()) * k, getY() + (lerpY - getY()) * k, getZ() + (lerpZ - getZ()) * k);
            float dyaw = MathHelper.wrapDegrees(lerpYaw - getYaw());
            setYaw(getYaw() + dyaw * (float) k);
            lerpSteps--;
        }
        prevWheelSpin = wheelSpin;
        prevWheelSteer = wheelSteer;
        double yr = Math.toRadians(getYaw());
        double vf = (getX() - prevX) * -Math.sin(yr) + (getZ() - prevZ) * Math.cos(yr);
        wheelSpin += (float) Math.toDegrees(vf / 0.32);
        float dyaw = MathHelper.wrapDegrees(getYaw() - prevYaw);
        if (Math.abs(vf) > 0.03) {
            double rate = Math.toRadians(-dyaw);
            double target = Math.toDegrees(Math.atan(WHEELBASE * rate / vf));
            target = MathHelper.clamp(target, -35.0, 35.0);
            wheelSteer += (float) (target - wheelSteer) * 0.4f;
        } else {
            wheelSteer *= 0.8f;
        }
    }

    private void serverTick() {
        PlayerEntity driver = getFirstPassenger() instanceof PlayerEntity p ? p : null;
        float throttle = driver != null ? driver.forwardSpeed : 0f;   // W = +1, S = -1
        float steer = driver != null ? driver.sidewaysSpeed : 0f;     // A = +1 (left), D = -1
        float dmg = getDamage();
        double engine = dmg >= 1f ? 0.0 : 1.0 - 0.6 * dmg;

        Vec3d vel = getVelocity();
        double yr = Math.toRadians(getYaw());
        double fx = -Math.sin(yr), fz = Math.cos(yr);
        double lx = Math.cos(yr), lz = Math.sin(yr);
        double vf = vel.x * fx + vel.z * fz;
        double vl = vel.x * lx + vel.z * lz;
        double vy = vel.y;
        boolean grounded = isOnGround();
        boolean inWater = isTouchingWater();

        if (grounded && !inWater) {
            double maxSpeed = MAX_SPEED * (0.5 + 0.5 * engine);
            if (throttle > 0.01f) {
                if (vf < -0.03) vf += BRAKE;
                else if (engine > 0) vf += ACCEL * engine * throttle * Math.max(0.0, 1.0 - vf / maxSpeed);
            } else if (throttle < -0.01f) {
                if (vf > 0.03) vf -= BRAKE;
                else if (engine > 0) vf -= REV_ACCEL * engine * Math.max(0.0, 1.0 - (-vf) / MAX_REVERSE);
            } else {
                vf *= 0.985;
            }
            vf -= vf * Math.abs(vf) * 0.02;
            if (engine <= 0) vf *= 0.97;

            double maxSteer = 0.55 / (1.0 + 2.5 * Math.abs(vf));
            double yawRate = vf / WHEELBASE * Math.tan(steer * maxSteer);
            setYaw(getYaw() - (float) Math.toDegrees(yawRate));
        } else if (inWater) {
            vf *= 0.9;
            vl *= 0.9;
        }

        // world velocity from the old basis, re-split in the new basis, lateral grip applied
        double wx = fx * vf + lx * vl;
        double wz = fz * vf + lz * vl;
        yr = Math.toRadians(getYaw());
        fx = -Math.sin(yr);
        fz = Math.cos(yr);
        lx = Math.cos(yr);
        lz = Math.sin(yr);
        double nf = wx * fx + wz * fz;
        double nl = (wx * lx + wz * lz) * (grounded ? 0.78 : 0.98);
        wx = fx * nf + lx * nl;
        wz = fz * nf + lz * nl;

        vy = (vy - 0.08) * 0.98;
        if (inWater) vy = vy * 0.8 - 0.005;

        setVelocity(wx, vy, wz);
        Vec3d before = getVelocity();
        move(MovementType.SELF, before);
        Vec3d after = getVelocity();

        handleCrash(before, after);
        runOver();
        damageEffects();
    }

    // ---------------------------------------------------------------- crashes

    private void handleCrash(Vec3d before, Vec3d after) {
        if (horizontalCollision) {
            double lostX = before.x - after.x;
            double lostZ = before.z - after.z;
            double lost = Math.hypot(lostX, lostZ);
            if (lost > 0.08) {
                Vec3d dir = new Vec3d(lostX, 0, lostZ);
                CarDamage.apply(this, dir, lost);
                hurtOccupants(lost);
                List<CarEntity> others = getWorld().getEntitiesByClass(CarEntity.class,
                        getBoundingBox().expand(0.35), c -> c != this);
                for (CarEntity other : others) {
                    CarDamage.apply(other, dir.negate(), lost * 0.9);
                    other.addVelocity(lostX * 0.9, 0, lostZ * 0.9);
                }
                Vec3d v = getVelocity();
                setVelocity(v.x * 0.6, v.y, v.z * 0.6);
            }
        }
        if (verticalCollision && before.y < -0.5) {
            double fall = -before.y - 0.4;
            CarDamage.apply(this, new Vec3d(0, -1, 0), fall * 0.8);
        }
    }

    private void hurtOccupants(double lost) {
        if (lost < 0.4) return;
        float amount = (float) ((lost - 0.35) * 22.0);
        for (Entity e : getPassengerList()) {
            e.damage(getDamageSources().flyIntoWall(), amount);
        }
    }

    private void runOver() {
        Vec3d v = getVelocity();
        double speed = Math.hypot(v.x, v.z);
        if (speed < 0.3) return;
        List<LivingEntity> list = getWorld().getEntitiesByClass(LivingEntity.class,
                getBoundingBox().expand(0.2, 0.0, 0.2),
                e -> e.isAlive() && !e.isSpectator() && !hasPassenger(e));
        for (LivingEntity e : list) {
            float dmg = (float) Math.min(20.0, (speed - 0.2) * 30.0);
            if (e.damage(getDamageSources().generic(), dmg)) {
                e.addVelocity(v.x * 0.9, 0.35, v.z * 0.9);
                e.velocityModified = true;
                CarDamage.apply(this, new Vec3d(v.x, 0, v.z), 0.08 + speed * 0.12);
                setVelocity(v.x * 0.92, v.y, v.z * 0.92);
            }
        }
    }

    private void damageEffects() {
        float dmg = getDamage();
        if (dmg < 0.55f || !(getWorld() instanceof ServerWorld sw)) return;
        if (age % 3 != 0) return;
        Vec3d hood = localToWorld(0, 1.1, 1.1);
        sw.spawnParticles(ParticleTypes.LARGE_SMOKE, hood.x, hood.y, hood.z, 1, 0.12, 0.05, 0.12, 0.02);
        if (dmg > 0.85f && age % 9 == 0) {
            sw.spawnParticles(ParticleTypes.FLAME, hood.x, hood.y, hood.z, 2, 0.15, 0.05, 0.15, 0.01);
        }
    }

    // ---------------------------------------------------------------- interaction

    @Override
    public ActionResult interact(PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        boolean client = getWorld().isClient;

        if (stack.isOf(Items.IRON_INGOT) && getDamage() > 0f) {
            if (!client) {
                setDamage(getDamage() - 0.12f);
                for (int i = 0; i < dents.length; i++) dents[i] *= 0.75f;
                if (getDamage() <= 0f) Arrays.fill(dents, 0f);
                syncDents();
                getWorld().playSound(null, getX(), getY(), getZ(), SoundEvents.BLOCK_ANVIL_USE,
                        SoundCategory.NEUTRAL, 0.6f, 1.2f);
                if (!player.isCreative()) stack.decrement(1);
            }
            return client ? ActionResult.SUCCESS : ActionResult.CONSUME;
        }

        if (stack.isOf(Items.GLASS_PANE) && (getGlass() & 0xFF) != 0) {
            if (!client) {
                int glass = getGlass();
                for (int p = 0; p < 4; p++) {
                    int mask = (1 << p) | (1 << (p + 4));
                    if ((glass & mask) != 0) {
                        setGlass(glass & ~mask);
                        break;
                    }
                }
                getWorld().playSound(null, getX(), getY(), getZ(), SoundEvents.BLOCK_GLASS_PLACE,
                        SoundCategory.NEUTRAL, 0.8f, 1.0f);
                if (!player.isCreative()) stack.decrement(1);
            }
            return client ? ActionResult.SUCCESS : ActionResult.CONSUME;
        }

        if (player.isSneaking()) return ActionResult.PASS;
        if (!client) {
            return player.startRiding(this) ? ActionResult.CONSUME : ActionResult.PASS;
        }
        return ActionResult.SUCCESS;
    }

    /** Sneak + punch picks the car up (drops the item); plain punches do nothing. */
    @Override
    public boolean damage(DamageSource source, float amount) {
        if (getWorld().isClient || isRemoved()) return true;
        if (source.getAttacker() instanceof PlayerEntity player && player.isSneaking()) {
            if (!player.isCreative()) dropStack(new ItemStack(RealCarsMod.CAR_ITEM));
            removeAllPassengers();
            discard();
            return true;
        }
        return false;
    }

    @Override
    public boolean canHit() {
        return !isRemoved();
    }

    @Override
    public boolean isCollidable() {
        return true;
    }

    // ---------------------------------------------------------------- passengers

    @Override
    public boolean canAddPassenger(Entity passenger) {
        return getPassengerList().size() < 2;
    }

    @Override
    public void updatePassengerPosition(Entity passenger, Entity.PositionUpdater positionUpdater) {
        if (!hasPassenger(passenger)) return;
        int idx = getPassengerList().indexOf(passenger);
        double lx = idx == 0 ? 0.40 : -0.40; // driver sits on the left
        Vec3d p = localToWorld(lx, -0.22, -0.15);
        positionUpdater.accept(passenger, p.x, p.y, p.z);
    }

    @Override
    public Vec3d updatePassengerForDismount(LivingEntity passenger) {
        double[] sides = {2.0, -2.0};
        for (double side : sides) {
            Vec3d p = localToWorld(side, 0, 0);
            Box box = passenger.getDimensions(passenger.getPose()).getBoxAt(p.x, getY(), p.z);
            if (getWorld().isSpaceEmpty(passenger, box)) {
                return new Vec3d(p.x, getY(), p.z);
            }
        }
        return new Vec3d(getX(), getBoundingBox().maxY, getZ());
    }

    // The car climbs slabs and stairs but not full blocks.
    public float getStepHeight() {
        return 0.6f;
    }

    // ---------------------------------------------------------------- persistence

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
        setDamage(nbt.getFloat("Damage"));
        if (nbt.contains("Color")) setColor(nbt.getInt("Color"));
        setGlass(nbt.getInt("Glass"));
        CarModel.decode(nbt.getByteArray("Dents"), dents);
        syncDents();
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
        nbt.putFloat("Damage", getDamage());
        nbt.putInt("Color", getColor());
        nbt.putInt("Glass", getGlass());
        nbt.putByteArray("Dents", CarModel.encode(dents));
    }
}
